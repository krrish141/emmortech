<div class="header_section">
    <div class="container">

        <div class="rows">
            <div class="col_md_3">
                <div class="logo_headers">
                    <a href="index.php"> <img src="assets/img/logo.png" alt=""></a>
                </div>
                <div class="mobo_button">
                    <span class="one"></span>
                    <span class="two"></span>
                    <span class="three"></span>
                </div>
            </div>
            <div class="col_md_9">

                <div class="main_menus mobo__menu_link">
                    <ul>

                        <li><img src="assets/img/home.png" alt=""> <a href="index.php" class="mobolikns accordion">
                                Home</a>
                        <li><img src="assets/img/company.png" alt=""> <a href="about-us.php"
                                class="mobolikns accordion"> About Us</a>

                        </li>
                        <!-- <li><a href="#">Facilities</a></li> -->
                        <li class="p_relative"><img src="assets/img/add-product.png" alt=""> <a href=""
                                class="accordion">Products <i class="fas fa-chevron-down"></i></a>
                            <div class="dropdpwnmenu panel">
                                <div class="submenus">
                                    <ul>
                                        <!--<li><a href="https://ikio.in/products">Products <svg viewBox="0 0 24 24" focusable="false" class="chakra-icon css-bokek7"><path fill="currentColor" d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"></path></svg></a></li>-->

                                        

                                        <li>
                                            <a href="./tws.php">
                                            TWS
                                                <svg viewbox="0 0 24 24"
                                                    focusable="false" class="chakra-icon css-bokek7">
                                                    <path fill="currentColor"
                                                        d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"></path>
                                                </svg>
                                            </a>
                                        </li>

                                        <li>
                                            <a href="./neckband.php">
                                            Neckband
                                                <svg viewbox="0 0 24 24"
                                                    focusable="false" class="chakra-icon css-bokek7">
                                                    <path fill="currentColor"
                                                        d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"></path>
                                                </svg>
                                            </a>
                                        </li>

                                       

                                        <li>
                                            <a href="./wired-earphone.php">
                                               Wired earphone

                                                <svg viewbox="0 0 24 24"
                                                    focusable="false" class="chakra-icon css-bokek7">
                                                    <path fill="currentColor"
                                                        d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"></path>
                                                </svg>
                                            </a>
                                        </li>

                                        <li>
                                            <a href="./powerbank.php">
                                            Power bank
                                                <svg viewbox="0 0 24 24"
                                                    focusable="false" class="chakra-icon css-bokek7">
                                                    <path fill="currentColor"
                                                        d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"></path>
                                                </svg>
                                            </a>
                                        </li>

                                        <li>
                                            <a href="./speaker.php">
                                            Speaker
                                                <svg viewbox="0 0 24 24"
                                                    focusable="false" class="chakra-icon css-bokek7">
                                                    <path fill="currentColor"
                                                        d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"></path>
                                                </svg>
                                            </a>
                                        </li>

                                        <li>
                                            <a href="./charger.php">
                                            Charger
                                                <svg viewbox="0 0 24 24"
                                                    focusable="false" class="chakra-icon css-bokek7">
                                                    <path fill="currentColor"
                                                        d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"></path>
                                                </svg>
                                            </a>
                                        </li>



                                    </ul>
                                </div>
                            </div>
                        </li>
                        <li><img src="assets/img/call-center.png" alt=""><a href="contact-us.php">Contact Us</a>
                        </li>
                    </ul>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- <div class="preloader" id="preloader">
        <svg viewbox="0 0 1920 1080" preserveaspectratio="none" version="1.1">
            <path
                d="M0,0 C305.333333,0 625.333333,0 960,0 C1294.66667,0 1614.66667,0 1920,0 L1920,1080 C1614.66667,1080 1294.66667,1080 960,1080 C625.333333,1080 305.333333,1080 0,1080 L0,0 Z">
            </path>
        </svg>
        <div class="inner">
            <canvas class="progress-bar" id="progress-bar" width="200" height="200"></canvas>
            <figure><img src="assets/img/logo.png" alt="Image"></figure>
            <div class="load-icon center">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
     
    </div> -->