<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Immortech Private Limited</title>


    <script src="ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="bootstrap/4.1.3/css/bootstrap.min.css">
    <script src="bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" media="screen" href="assets/css/custom.css?v=4">
    <link rel="stylesheet" type="text/css" media="screen" href="assets/css/new.css?v=3">
    <link rel="stylesheet" type="text/css" media="screen" href="assets/css/media.css?v=3">
    <link rel="stylesheet" href="assets/owlcarousel/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/owlcarousel/assets/owl.theme.default.min.css">
    <script src="assets/owlcarousel/owl.carousel.js"></script>
    <link rel="stylesheet" href="releases/v5.7.2/css/all.css">
    <link href="ajax/libs/Swiper/4.0.7/css/swiper.min.css" rel="stylesheet">
    <link href="aos%402.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">

</head>


<body>

<?php include("header.php")?>

<?php include("footer.php")?>
</body>

</html>